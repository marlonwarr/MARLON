const help = (prefix) => {
	return `
╭ ─ ─═「 *𝗠𝗔𝗥𝗟𝗢𝗡 𝗪𝗔𝗥 𝗕𝗢𝗧* 」
│
│bot feito por MARLON WAR😌
│design : MARLON
│data de criação :15 de janeiro de 2021
│
│📌 Prefix:  *「 ${prefix} 」*
│🔎 Status: *「 Online 」*
│
│
│Para mais informações
│digite *${prefix}dono*
│
├ ─ ─ ─ ─ ─ ─ ─ ─
│𝗠𝗔𝗥𝗟𝗢𝗡 𝗪𝗔𝗥 𝗗𝗢𝗠𝗜𝗡𝗔🤏😎
├ ─ ─ ─ ─ ─ ─ ─ ─ 
│
│
╭─────⊣〘 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔 〙
│    
┝➥ *${prefix}sticker* ou *${prefix}stiker*
│➛ converter imagem/gif/vídeo em
│adesivo
│
┝➥ *${prefix}sticker nobg* ou *${prefix}stiker nobg*
│➛ converter imagem em figurinha
│removendo o fundo
│
┝➥ *${prefix}toimg*
│➛ converter figurinha em imagem
│
┝➥ *${prefix}tsticker* ou *${prefix}tstiker*
│➛ converter texto em adesivo
│
╭─────⊣〘 𝗠𝗘𝗠𝗘 〙
│      
┝➥ *${prefix}meme*
│➛ mandar imagens aleatórias de
│ meme [inglês]
│
┝➥ *${prefix}memeindo*
│➛ mandar imagens aleatórias de
│ meme [indo]
│
╭─────⊣〘 𝗣𝗘𝗥𝗜𝗣𝗘𝗖𝗜𝗔𝗦 〙
│
│➛ manda imagem de cada
│➛ coisa/pessoa
│
┝➥*${prefix}akeno*
┝➥*${prefix}belle*
┝➥*${prefix}belle1*
┝➥*${prefix}belle2*
┝➥*${prefix}belle3*
┝➥*${prefix}hentai*
┝➥*${prefix}hilih*
┝➥*${prefix}loli1*
┝➥*${prefix}malkova*
┝➥*${prefix}mia*
┝➥*${prefix}mia1*
┝➥*${prefix}mia2*
┝➥*${prefix}nsfwloli*
┝➥*${prefix}porno*
┝➥*${prefix}reislin*
│
╭─────⊣〘 𝗢𝗨𝗧𝗥𝗢𝗦 〙
│
┝➥ chegada 
│➛ *${prefix}boanoite*
│➛ *${prefix}bomdia*
│➛ *${prefix}boatarde*
│
┝➥ *${prefix}gtts*
│➛ converter texto em fala/áudio
│ *[ OFF ]*
│
┝➥ *${prefix}ocr*
│➛ pegar o texto da foto e lhe enviar
│
┝➥ *${prefix}simi*
│➛ responder sua mensagem por simi
│➛ *${prefix}simi sua mensagem*\n
│
┝➥ tick tock
│➛ *${prefix}tiktok*
│➛ pesquisa vídeo do tick tock
│
│➛ *${prefix}tiktokstalk*
│➛ pesquisa user do tick tock
│
┝➥ *${prefix}url2img*
│➛ tirar screenshots da web
│ *[ OFF ]*
│
┝➥ *${prefix}wait*
│➛ pesquisar sobre o anime por
│ imagem [ Que anime é este ]
│
┝➥ *${prefix}ytsearch*
│➛pesquisa algo do youtube
│
┝➥ *${prefix}loli1*
│➛ mandar imagens aleatórias de loli
│
┝➥ *${prefix}nsfwloli*
│➛ mandar imagens aleatórias de nsfw
│ loli
│
┝➥ *${prefix}setprefix*
│➛ alterar o prefixo do bot
│➛exemplo : *${prefix}setprefix ?*
│
│⚠️ Usado somente pelo proprietário
│do bot
│
╭─────⊣〘 𝗚𝗥𝗨𝗣𝗢 〙
│
│
┝➥ *${prefix}add*
│➛ adicionar membro ao grupo
│➛ *${prefix}add 5511xxxxx*
│
│⚠️ o bot precisa ser admin
│
┝➥ *${prefix}demote*
│➛ tornar o administrador um membro comum
│➛ *${prefix}demote e o 
│@da pessoa*\n
│
│ ⚠️ Você precisa ser admin e o 
│bot também
│
┝➥ *${prefix}demote*
│➛ tornar o administrador um membro comum
│➛ *${prefix}demote e o 
│@da pessoa*\n
│
│⚠️ Você precisa ser admin e o 
│bot também
│
┝➥ *${prefix}linkgroup*
│➛ enviar o link do grupo
│
┝➥ *${prefix}listadmins

┝➥ *${prefix}marcar*
│➛ marcar todos os membros do
│grupo, incluindo administradores
│➛ marcar1, marcar2, marcar3
│
┝➥ *${prefix}promote*
│➛ tornar membro do grupo um administrador
│➛ *${prefix}promote e o @da pessoa*
│
│ ⚠️ Você precisa ser admin e o
│bot também
│
┝➥ *${prefix}simih*
│
│➛ ativar o modo simi no grupo 
│➛ *${prefix}simih 1*  ↲
│
│➛ desativar o modo simih 
│➛ *${prefix}simih 0* 
│
│⚠️ Você precisa ser admin
│
┝➥welcome
│
│➛ ativar o modo boas vindas 
│➛ *${prefix}welcome 1*  ↲
│
│➛ desativar o modo boas vindas 
│➛ *${prefix}welcome 0* ↲
│
╭─────⊣〘 𝗕𝗢𝗧 〙
│
┝➥ *${prefix}blocklist*
│➛ lista de bloqueados do bot
│➛do bot
│
┝➥ *${prefix}canal*
│➛ canal do criador do bot
│ *[ OFF ]*
│
┝➥ *${prefix}clone*
│➛clona dados de outro user
│
│⚠️ Usado somente pelo proprietário
│do bot
│
┝➥ *${prefix}dono*
│➛ créditos do criador do bot
│
┝➥ *${prefix}limpar*
│➛ limpa os chats so bot
│
│⚠️ Usado somente pelo proprietário
│do bot
│
┝➥ *${prefix}setprefix
│➛ seta outro prefix no bot
│
│⚠️ Usado somente pelo proprietário
│do bot
│
┝➥ *${prefix}ts*
│➛inicia uma transamição
│ 
│⚠️ Usado somente pelo proprietário
│do bot
│ 
╰─ ─═「 *𝗠𝗔𝗥𝗟𝗢𝗡 𝗪𝗔𝗥 𝗕𝗢𝗧* 」



╭─────⊣〘 𝗠𝗘𝗡𝗨 𝗚𝗘𝗥𝗔𝗟 〙
│
├➤ *${prefix}help1* ♔
│
╰ ─ ─ ─ ─ ─ ─ ─ ─`
}

exports.help = help








































